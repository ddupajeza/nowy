# NitroSniper

[![Views](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/Vedza/NitroSniper&title=Views)](https://github.com/Vedza/NitroSniperGo)                    
Discord Nitro sniper and Giveaway joiner 

> :warning: **I made a better and faster sniper that you should use instead https://github.com/Vedza/NitroSniperGo**

![Screenshot](screenshot.png)


### USE :
```
python3.8 -m pip install httpx discord.py colorama
python3.8 sniper.py
```

### How to obtain your token
https://github.com/Tyrrrz/DiscordChatExporter/wiki/Obtaining-Token-and-Channel-IDs#how-to-get-a-user-token


### Disclaimer
This can get your account banned if you run multiple instance at the same time and/or claim too much Nitros in a too short amount of time. Use it at your own risks.
